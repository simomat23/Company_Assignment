package assignment3;

public class Manager extends Employee{ //Task 1.3 Simona and Bimnet
    private String degree;

    public Manager(String id, String name, double grossSalary, String degree) throws Exception{
        super(id, name, grossSalary);

        if(!degree.equals("BSc") && !degree.equals("MSc") && !degree.equals("PhD")){

            throw new DegreeMustExist();
        }else{
            this.degree = degree;
        }
    }

    public void setDegree(String degree) throws Exception{

        if(!degree.equals("BSc") && !degree.equals("MSc") && !degree.equals("PhD")){

            throw new DegreeMustExist();
        }else{
            this.degree = degree;
        }
    }

    public String getDegree() {
        return degree;
    }

    @Override
    public double getGrossSalary() {

        double grossSalary = super.getGrossSalary();

        double BScBonus = 0.1;
        double MScBonus = 0.2;
        double PhDBonus = 0.35;

        if(this.degree.equals("BSc")){
            grossSalary = (int)((grossSalary + (grossSalary*BScBonus))*100);
            grossSalary = grossSalary/100;

        }else if(this.degree.equals("MSc")){
            grossSalary = (int)((grossSalary + (grossSalary*MScBonus))*100);
            grossSalary = grossSalary/100;

        }else if(this.degree.equals("PhD")) {
            grossSalary = (int)((grossSalary + (grossSalary*PhDBonus))*100);
            grossSalary = grossSalary/100;

        }

        return grossSalary;
    }

    @Override
    public String toString() {
        String message = this.degree + " ";

        message += super.toString();

        return message;
    }

}
