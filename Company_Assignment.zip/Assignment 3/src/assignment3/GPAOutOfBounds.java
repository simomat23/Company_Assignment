package assignment3;

public class GPAOutOfBounds extends Exception{ //Task 2.6 Simona

    public GPAOutOfBounds(String message) throws Exception{
        super(message);
    }
}
