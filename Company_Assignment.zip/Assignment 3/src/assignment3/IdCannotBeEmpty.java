package assignment3;

public class IdCannotBeEmpty extends Exception{

    public IdCannotBeEmpty(){
        super("ID cannot be blank.");
    }

    public IdCannotBeEmpty(String message) throws Exception{
        super(message);
    }
}
