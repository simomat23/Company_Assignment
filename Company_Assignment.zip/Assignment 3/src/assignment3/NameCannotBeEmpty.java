package assignment3;

public class NameCannotBeEmpty extends Exception{

    public NameCannotBeEmpty(){
        super("Name cannot be blank.");
    }

    public NameCannotBeEmpty(String message) throws Exception{
        super(message);
    }
}
