package assignment3;

public class Director extends Manager{ //Task 1.3 Simona and Bimnet
    private String department;

    public Director(String id, String name, double grossSalary, String degree, String department) throws Exception{
        super(id, name, grossSalary, degree);

        if(!department.equals("Business") && !department.equals("Human Resources") && !department.equals("Technical")){

            throw new DeptMustExist();
        }else{
            this.department = department;
        }
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) throws Exception{

        if(!department.equals("Business") && !department.equals("Human Resources") && !department.equals("Technical")){

            throw new DeptMustExist();
        }else{
            this.department = department;
        }
    }

    @Override
    public double getGrossSalary() {
        int bonus = 5000;

        double salary = super.getGrossSalary() + bonus;

        return salary;
    }

    @Override
    public String toString() {
        String message =  super.toString();

        message += " Dept: " + this.department;

        return message;
    }

    @Override
    public double calcNetSalary() {
        double netSalary = 0;
        double normalTax = 0.1;
        double betweenTax = 0.2;
        double greaterTax = 0.4;

        if(this.getGrossSalary() < 30000){

            netSalary = super.calcNetSalary();

        }else if(this.getGrossSalary() >= 30000 && this.getGrossSalary() <= 50000){

            netSalary = this.getGrossSalary() - (this.getGrossSalary() * betweenTax);

        }else if(this.getGrossSalary() > 50000){

            double firstThirtyK = 30000;
            double restOfMoney = this.getGrossSalary() - firstThirtyK;

            netSalary = this.getGrossSalary() - (firstThirtyK * betweenTax) - (restOfMoney * greaterTax);

        }

        return netSalary;
    }
}
