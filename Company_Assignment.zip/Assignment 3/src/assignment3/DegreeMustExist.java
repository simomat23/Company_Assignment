package assignment3;

public class DegreeMustExist extends Exception{ //Task 2.4 Simona

    public DegreeMustExist(){
        super("Degree must be one of the options: BSc, MSc or PhD.");
    }

    public DegreeMustExist(String message) throws Exception{
        super(message);
    }
}
