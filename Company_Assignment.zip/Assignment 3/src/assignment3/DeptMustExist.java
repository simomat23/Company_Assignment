package assignment3;

public class DeptMustExist extends Exception{ //Task 2.5 Simona

    public DeptMustExist(){
        super("Department must be one of the options: Business, Human Resources or Technical.");
    }

    public DeptMustExist(String message) throws Exception{
        super(message);
    }
}
