package assignment3;

public class SalaryMustBeGreaterThanZero extends Exception{

    public SalaryMustBeGreaterThanZero(){
        super("Salary must be greater than zero.");
    }

    public SalaryMustBeGreaterThanZero(String message) throws Exception{
        super(message);
    }
}
