package assignment3;

import java.util.*;

public class Company {
    private String name;
    private ArrayList<Employee> allEmployees;

    final String EOL = System.lineSeparator();

    //All the constructors
    public Company(){
        allEmployees = new ArrayList<Employee>();
    }

    public String createEmployee(String id, String name, double grossSalary) throws Exception{
        String message = "";

        throwIDAlreadyRegistered(id);

        Employee anEmployee = EmployeeFactory.createEmployee(id, name, grossSalary);

        allEmployees.add(anEmployee);

        message = "Employee " + anEmployee.getId() + " was registered successfully.";


        return message;
    }

    public String createEmployee(String id, String name, double grossSalary, String degree) throws Exception{
        String message = "";

        throwIDAlreadyRegistered(id);

        Employee anEmployee = EmployeeFactory.createManager(id, name, grossSalary, degree);

        allEmployees.add(anEmployee);

        message = "Employee " + anEmployee.getId() + " was registered successfully.";

        return message;
    }

    public String createEmployee(String id, String name, double grossSalary, int gpa) throws Exception{
        String message = "";

        throwIDAlreadyRegistered(id);

        Employee anEmployee = EmployeeFactory.createIntern(id, name, grossSalary, gpa);

        allEmployees.add(anEmployee);

        message = "Employee " + anEmployee.getId() + " was registered successfully.";

        return message;
    }

    public String createEmployee(String id, String name, double grossSalary, String degree, String department) throws Exception{
        String message = "";

        throwIDAlreadyRegistered(id);

        Employee anEmployee = EmployeeFactory.createDirector(id, name, grossSalary, degree, department);

        allEmployees.add(anEmployee);

        message = "Employee " + anEmployee.getId() + " was registered successfully.";

        return message;
    }

    //Methods to search for, remove and print employees

    public Employee searchEmployee(String id){
        Employee anEmployee = null;

        for(Employee someEmployee : this.allEmployees){
            if(someEmployee.getId().equals(id)){
                anEmployee = someEmployee;
            }
        }

        return anEmployee;
    }

    public String printEmployee(String id) throws Exception{ //Task 1.5 - Simona
        String message = "";

        throwMissingEmployee(id);

        message = searchEmployee(id).toString();

        return message;
    }

    public String printAllEmployees() throws Exception{ //Task 1.6 - Simona
        String message = "All registered employees:" + EOL;

        throwNoEmployees();

        for(Employee employee : this.allEmployees){

            message += employee.toString() + EOL;
        }

        return message;
    }

    public String removeEmployee(String id) throws Exception{ //Task 1.4 - Simona
        String message = "";

        throwMissingEmployee(id);

        allEmployees.remove(searchEmployee(id));

        message = "Employee " + id + " was successfully removed.";


        return message;
    }

    //get the net Salary of employees method
    public double getNetSalary(String id) throws Exception{
        double netSalary = 0;

        throwMissingEmployee(id);

        netSalary = searchEmployee(id).calcNetSalary();

        return netSalary;
    }

    //get the total net salaries of all employees, so how much the company is spending in salaries
    public double getTotalNetSalary() throws Exception{ //Task 1.7 - Simona

        double totalNetSalaries = 0;

        throwNoEmployees();

        for(Employee employee : this.allEmployees ){

            totalNetSalaries += getNetSalary(employee.getId());
        }
        totalNetSalaries = (int) (totalNetSalaries * 100);
        totalNetSalaries = totalNetSalaries/100;

        return totalNetSalaries;
    }

    //updating employee attributes methods
    public String updateEmployeeName(String id, String name) throws Exception{
        String message = "";

        throwMissingEmployee(id);

        searchEmployee(id).setName(name);

        message = "Employee " + id + " was updated successfully";

        return message;
    }

    public String updateGrossSalary(String id, double newGrossSalary) throws Exception{
        String message = "";

        throwMissingEmployee(id);

        searchEmployee(id).setGrossSalary(newGrossSalary);

        message = "Employee " + id + " was updated successfully";

        return message;
    }

    public String updateManagerDegree(String id, String newDegree) throws Exception{
        String message = "";

        throwMissingEmployee(id);

        if(searchEmployee(id) instanceof Manager){
            Manager employee = (Manager)searchEmployee(id);

            employee.setDegree(newDegree);
        }else if(searchEmployee(id) instanceof Director){
            Director anEmployee = (Director)searchEmployee(id);

            anEmployee.setDegree(newDegree);
        }
        message = "Employee " + id + " was updated successfully";

        return message;
    }

    public String updateDirectorDept(String id, String newDept) throws Exception{
        String message = "";

        throwMissingEmployee(id);

        if(searchEmployee(id) instanceof Director){
            Director employee = (Director)searchEmployee(id);

            employee.setDepartment(newDept);
        }

        message = "Employee " + id + " was updated successfully";

        return message;
    }

    public String updateInternGPA(String id, int newGpa) throws Exception{
        String message = "";

        throwMissingEmployee(id);

        if(searchEmployee(id) instanceof Intern){
            Intern employee = (Intern)searchEmployee(id);

            employee.setGpa(newGpa);
        }

        message = "Employee " + id + " was updated successfully";

        return message;
    }


    //the sort method in order to print employees from lowest to highest in gross salary
    public String printSortedEmployees() throws Exception{
        String message = "";

        throwNoEmployees();

        ArrayList<Employee> employeesCopy = this.allEmployees;

        Collections.sort(employeesCopy);

        message = "Employees sorted by gross salary (ascending order):" + EOL;

        for(Employee employee : employeesCopy){

            message += employee + EOL;

        }

        return message;
    }

    //mapping all the degrees and printing how many employees have a certain degree
    public HashMap<String, Integer> mapEachDegree() throws Exception{

        throwNoEmployees();

        HashMap<String, Integer> eachDegree = new HashMap<>();

        for(Employee anEmployee : this.allEmployees){

            if(anEmployee instanceof Manager){
                Manager employee = (Manager)anEmployee;

                if(!eachDegree.containsKey(employee.getDegree())){
                    eachDegree.put(employee.getDegree(), 1);

                }else {
                    int numOfDegree = eachDegree.get(employee.getDegree());
                    numOfDegree++;
                    eachDegree.put(employee.getDegree(), numOfDegree);
                }
            }
        }

        return eachDegree;
    }

    //updating employee position in the company

    public String promoteToManager(String id, String requiredDeg) throws Exception{ //Task 1.11 - Simona
        String message = "";

        throwMissingEmployee(id);

        String name = searchEmployee(id).getName();
        double rawGrossSalary = searchEmployee(id).getRawSalary();

        this.allEmployees.remove(searchEmployee(id));

        createEmployee(id, name, rawGrossSalary, requiredDeg);

        message = id + " promoted successfully to Manager.";

        return message;
    }

    public String promoteToDirector(String id, String requiredDeg, String dept) throws Exception{ //Task 1.11 - Simona
        String message = "";

        throwMissingEmployee(id);

        String name = searchEmployee(id).getName();
        double rawGrossSalary = searchEmployee(id).getRawSalary();

        this.allEmployees.remove(searchEmployee(id));

        createEmployee(id, name, rawGrossSalary, requiredDeg, dept);

        message = id + " promoted successfully to Director.";

        return message;
    }

    public String promoteToIntern(String id, int gpa) throws Exception{ //Task 1.11 - Simona
        String message = "";

        throwMissingEmployee(id);

        String name = searchEmployee(id).getName();
        double rawGrossSalary = searchEmployee(id).getRawSalary();

        this.allEmployees.remove(searchEmployee(id));

        createEmployee(id, name, rawGrossSalary, gpa);

        message = id + " promoted successfully to Intern.";

        return message;
    }

    public void throwMissingEmployee(String id) throws Exception{ // Tasks 2.4-2.6 Simona

        if(searchEmployee(id) == null){

            throw new IDException("Employee " + id + " was not registered yet.");
        }

    }

    public void throwNoEmployees() throws Exception{ // Task 2.1 Bimnet

        if(this.allEmployees.isEmpty()){

            throw new IDException("No employees registered yet.");
        }
    }

    public void throwIDAlreadyRegistered(String id) throws Exception{ // Task 2.2 Bimnet

        if(searchEmployee(id) != null){

            throw new IDException("Cannot register. ID " + id + " is already registered.");
        }
    }
}

