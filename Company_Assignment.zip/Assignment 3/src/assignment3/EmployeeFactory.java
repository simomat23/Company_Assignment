package assignment3;

public class EmployeeFactory { //Design Task Simona and Bimnet

    public static Employee createEmployee(String id, String name, double grossSalary) throws Exception{
        Employee employee = new Employee(id, name, grossSalary);

        return employee;
    }

    public static Employee createManager(String id, String name, double grossSalary, String degree) throws Exception{
        Employee employee = new Manager(id, name, grossSalary, degree);

        return employee;
    }

    public static Employee createDirector(String id, String name, double grossSalary, String degree, String dept) throws Exception{
        Employee employee = new Director(id, name, grossSalary, degree, dept);

        return employee;
    }

    public static Employee createIntern(String id, String name, double grossSalary, int gpa) throws Exception{
        Employee employee = new Intern(id, name, grossSalary, gpa);

        return employee;
    }
}
