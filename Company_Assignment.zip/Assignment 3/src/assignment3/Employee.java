package assignment3;

public class Employee implements Comparable<Employee>{ //Task 1.3 Simona and Bimnet
    private final String id;
    private String name;
    private double grossSalary;

    public Employee(String id, String name, double grossSalary) throws Exception{
        if(name.isBlank()){
            throw new NameCannotBeEmpty();
        }else{
            this.name = name;
        }
        if(id.isBlank()){
            throw new IdCannotBeEmpty();
        }else{
            this.id = id;
        }
        if(grossSalary < 0){
            throw new SalaryMustBeGreaterThanZero();
        }else{
            this.grossSalary = truncateSalary(grossSalary);
        }
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) throws Exception{
        if(name.isBlank()){

            throw new NameCannotBeEmpty();
        }else{
            this.name = name;
        }
    }

    public double truncateSalary(double salary){
        salary = (int)(salary*100);
        salary = salary/100;

        return salary;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public double getRawSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) throws Exception{
        if(grossSalary <= 0){

            throw new SalaryMustBeGreaterThanZero();
        }else{
            this.grossSalary = grossSalary;
        }
    }

    @Override
    public boolean equals(Object anEmployee) {
        boolean theSame = false;

        if(anEmployee == this){
            theSame = true;
        }else if(anEmployee == null){
            theSame = false;
        }else if(anEmployee instanceof Employee){
            Employee otherEmployee = (Employee)anEmployee;
            boolean sameID = this.id.equals(((Employee) anEmployee).id);

            theSame = sameID;
        }
        return theSame;
    }

    @Override
    public String toString() {
        String message;
        message = String.format("%s's gross salary is %.2f SEK per month.", this.name, getGrossSalary());

        return message;
    }

    public double calcNetSalary(){
        double netSalary;
        double normalTax = 0.1;

        netSalary = this.getGrossSalary() - (this.getGrossSalary() * normalTax);
        netSalary = truncateSalary(netSalary);

        return netSalary;
    }

    @Override
    public int compareTo(Employee employee){
        int returnValue;

        if(this.getGrossSalary() > employee.getGrossSalary()){
            returnValue = 1;
        }else if(this.getGrossSalary() < employee.getGrossSalary()){
            returnValue = -1;
        }else{
            returnValue = 0;
        }

        return returnValue;
    }
}

