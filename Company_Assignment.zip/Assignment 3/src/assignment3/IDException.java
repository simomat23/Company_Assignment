package assignment3;

public class IDException extends Exception {

    public IDException(String message) throws Exception{
        super(message);
    }
}
