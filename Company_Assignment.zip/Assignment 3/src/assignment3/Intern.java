package assignment3;

public class Intern extends Employee{ //Task 1.3 Simona and Bimnet
    private int gpa;

    public Intern(String id, String name, double grossSalary, int gpa) throws Exception{
        super(id, name, grossSalary);

        if(gpa < 0 || gpa > 10){

            throw new GPAOutOfBounds(gpa + " outside range. Must be between 0-10.");
        }else{
            this.gpa = gpa;
        }
    }

    @Override
    public double getGrossSalary() {
        double salary = super.getGrossSalary();
        double reward = 1000;

        if(this.gpa <= 5){
            salary = 0;
        }else if(this.gpa >= 5 && this.gpa <= 8){
            salary = super.getGrossSalary();
        }else{
            salary = salary + reward;
        }

        return salary;
    }

    public void setGpa(int gpa) throws Exception{

        if(gpa < 0 || gpa > 10){

            throw new GPAOutOfBounds(gpa + " outside range. Must be between 0-10.");
        }else{
            this.gpa = gpa;
        }
    }

    @Override
    public String toString() {
        String message = super.toString();

        message += " GPA: " + this.gpa;

        return message;
    }

    @Override
    public double calcNetSalary(){
        return this.getGrossSalary();
    }
}
